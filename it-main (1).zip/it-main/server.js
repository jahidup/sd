// server.js – Sankalp Digital Pathshala (Complete, Production‑Ready, AI Trained)
require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const rateLimit = require('express-rate-limit');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB error:', err));

// ========== SCHEMAS ==========
const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true, lowercase: true },
  phone: { type: String, required: true },
  password: { type: String, required: true },
  isVerified: { type: Boolean, default: false },
  role: { type: String, enum: ['student', 'admin'], default: 'student' }
}, { timestamps: true });
const User = mongoose.model('User', userSchema);

const lectureSchema = new mongoose.Schema({
  title: String,
  videoUrl: String,
  notesUrl: String,
  dppLink: String,
  thumbnail: String,
  createdAt: { type: Date, default: Date.now }
});
const chapterSchema = new mongoose.Schema({
  title: { type: String, required: true },
  lectures: [lectureSchema]
});
const courseSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  price: { type: Number, required: true },
  originalPrice: { type: Number, default: null },
  imageUrl: { type: String, default: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=600' },
  chapters: [chapterSchema]
}, { timestamps: true });
const Course = mongoose.model('Course', courseSchema);

const enrollmentSchema = new mongoose.Schema({
  userEmail: { type: String, required: true },
  courseId: { type: mongoose.Schema.Types.ObjectId, ref: 'Course', required: true },
  enrolledAt: { type: Date, default: Date.now }
});
const Enrollment = mongoose.model('Enrollment', enrollmentSchema);

const otpSchema = new mongoose.Schema({
  email: { type: String, required: true },
  otp: { type: String, required: true },
  expiresAt: { type: Date, required: true },
  verified: { type: Boolean, default: false },
  purpose: { type: String, enum: ['registration', 'reset'], default: 'registration' }
});
otpSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });
const OTP = mongoose.model('OTP', otpSchema);

const lectureProgressSchema = new mongoose.Schema({
  userEmail: String,
  courseId: { type: mongoose.Schema.Types.ObjectId, ref: 'Course' },
  lectureId: String,
  completedAt: { type: Date, default: Date.now }
});
const LectureProgress = mongoose.model('LectureProgress', lectureProgressSchema);

const doubtSchema = new mongoose.Schema({
  userEmail: { type: String, required: true },
  userName: { type: String, required: true },
  courseId: { type: mongoose.Schema.Types.ObjectId, ref: 'Course', required: true },
  chapterId: { type: String, required: true },
  lectureId: { type: String, required: true },
  parentId: { type: mongoose.Schema.Types.ObjectId, default: null },
  message: { type: String, required: true },
  adminReply: { type: String, default: '' },
  createdAt: { type: Date, default: Date.now }
});
const Doubt = mongoose.model('Doubt', doubtSchema);

// Test schemas with scheduling and live/draft
const questionSchema = new mongoose.Schema({
  type: { type: String, enum: ['mcq', 'numerical'], required: true },
  questionText: String,
  questionImage: String,
  options: [String],
  correctAnswer: String,
  marks: { type: Number, default: 1 },
  explanation: { type: String, default: '' }
});

const testSchema = new mongoose.Schema({
  courseId: { type: mongoose.Schema.Types.ObjectId, ref: 'Course', required: true },
  title: String,
  description: String,
  duration: { type: Number, required: true },
  language: { type: String, enum: ['english', 'hindi', 'both'], default: 'english' },
  startTime: { type: Date, default: null },
  endTime: { type: Date, default: null },
  isLive: { type: Boolean, default: false },
  negativeMarking: { type: Number, default: 0 },
  questions: [questionSchema],
  createdAt: { type: Date, default: Date.now }
});
const Test = mongoose.model('Test', testSchema);

const testAttemptSchema = new mongoose.Schema({
  testId: { type: mongoose.Schema.Types.ObjectId, ref: 'Test', required: true },
  userEmail: String,
  startTime: Date,
  endTime: Date,
  score: { type: Number, default: 0 },
  totalMarks: Number,
  answers: [{
    questionId: mongoose.Schema.Types.ObjectId,
    selectedAnswer: String,
    isCorrect: Boolean,
    marksObtained: Number
  }],
  completed: { type: Boolean, default: false },
  tabSwitchCount: { type: Number, default: 0 }
});
const TestAttempt = mongoose.model('TestAttempt', testAttemptSchema);

const practiceTestSchema = new mongoose.Schema({
  userEmail: String,
  topic: String,
  difficulty: String,
  questions: [questionSchema],
  startedAt: Date,
  completedAt: Date,
  score: Number,
  totalMarks: Number,
  answers: [{
    questionId: mongoose.Schema.Types.ObjectId,
    selectedAnswer: String,
    isCorrect: Boolean,
    marksObtained: Number
  }],
  completed: { type: Boolean, default: false }
});
const PracticeTest = mongoose.model('PracticeTest', practiceTestSchema);

const conversationSchema = new mongoose.Schema({
  userEmail: String,
  messages: [{
    role: String,
    content: String,
    timestamp: { type: Date, default: Date.now }
  }],
  updatedAt: { type: Date, default: Date.now }
});
const Conversation = mongoose.model('Conversation', conversationSchema);

const notificationSchema = new mongoose.Schema({
  sender: { type: String, default: 'admin' },
  recipient: { type: String, default: null },
  courseId: { type: mongoose.Schema.Types.ObjectId, ref: 'Course', default: null },
  message: String,
  createdAt: { type: Date, default: Date.now }
});
const Notification = mongoose.model('Notification', notificationSchema);

const messageSchema = new mongoose.Schema({
  from: String,
  to: String,
  message: String,
  createdAt: { type: Date, default: Date.now }
});
const Message = mongoose.model('Message', messageSchema);

const communityMessageSchema = new mongoose.Schema({
  userEmail: String,
  userName: String,
  message: String,
  createdAt: { type: Date, default: Date.now }
});
const CommunityMessage = mongoose.model('CommunityMessage', communityMessageSchema);

// Performance indexes
User.schema.index({ email: 1 });
Enrollment.schema.index({ userEmail: 1, courseId: 1 });
LectureProgress.schema.index({ userEmail: 1, courseId: 1 });
TestAttempt.schema.index({ testId: 1, userEmail: 1 });
Doubt.schema.index({ courseId: 1, lectureId: 1 });
Notification.schema.index({ recipient: 1, createdAt: -1 });
Message.schema.index({ from: 1, to: 1, createdAt: 1 });

// ========== MIDDLEWARE ==========
const authMiddleware = (req, res, next) => {
  const token = req.header('Authorization')?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ message: 'No token provided.' });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch (err) { res.status(401).json({ message: 'Invalid token.' }); }
};

const adminMiddleware = (req, res, next) => {
  authMiddleware(req, res, () => {
    if (req.user.role !== 'admin') return res.status(403).json({ message: 'Admin access required.' });
    next();
  });
};

// ========== EMAIL SETUP ==========
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS }
});
const ALLOWED_DOMAINS = ['gmail.com','yahoo.com','outlook.com','hotmail.com','aol.com','icloud.com','protonmail.com','zoho.com','yandex.com','mail.com'];
const generateOTP = () => Math.floor(100000 + Math.random() * 900000).toString();

// ========== AUTH ROUTES ==========
app.post('/api/auth/send-otp',
  rateLimit({ windowMs: 15 * 60 * 1000, max: 3, message: 'Too many OTP requests.' }),
  async (req, res) => {
    try {
      const { email } = req.body;
      if (!email) return res.status(400).json({ message: 'Email required.' });
      const domain = email.split('@')[1];
      if (!ALLOWED_DOMAINS.includes(domain))
        return res.status(400).json({ message: 'Only popular email providers allowed.' });
      const existingUser = await User.findOne({ email });
      if (existingUser?.isVerified) return res.status(400).json({ message: 'Email already registered.' });

      await OTP.deleteMany({ email, purpose: 'registration' });
      const otp = generateOTP();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000);
      await new OTP({ email, otp, expiresAt, purpose: 'registration' }).save();

      await transporter.sendMail({
        from: `"Sankalp Digital Pathshala" <${process.env.EMAIL_USER}>`,
        to: email,
        subject: 'Your OTP for Registration',
        html: `<h2>Welcome!</h2><p>Your OTP is: <strong>${otp}</strong></p><p>Expires in 10 minutes.</p>`
      });
      res.json({ message: 'OTP sent to your email.' });
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: 'Server error.' });
    }
  });

app.post('/api/auth/verify-otp', async (req, res) => {
  try {
    const { email, otp } = req.body;
    const record = await OTP.findOne({ email, otp, purpose: 'registration' });
    if (!record) return res.status(400).json({ message: 'Invalid OTP.' });
    if (record.verified) return res.status(400).json({ message: 'OTP already used.' });
    if (new Date() > record.expiresAt) { await OTP.deleteMany({ email, purpose: 'registration' }); return res.status(400).json({ message: 'OTP expired.' }); }
    record.verified = true; await record.save();
    res.json({ message: 'OTP verified.' });
  } catch (err) { res.status(500).json({ message: 'Server error.' }); }
});

app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, phone, password, otp } = req.body;
    if (!name || !email || !phone || !password || !otp) return res.status(400).json({ message: 'All fields required.' });
    const domain = email.split('@')[1];
    if (!ALLOWED_DOMAINS.includes(domain)) return res.status(400).json({ message: 'Only popular email providers allowed.' });
    const existingUser = await User.findOne({ email });
    if (existingUser) return res.status(400).json({ message: 'Email already registered.' });
    const otpRecord = await OTP.findOne({ email, otp, verified: true, purpose: 'registration' });
    if (!otpRecord) return res.status(400).json({ message: 'OTP not verified.' });

    const hashed = await bcrypt.hash(password, 10);
    const user = await new User({ name, email, phone, password: hashed, isVerified: true, role: 'student' }).save();
    await OTP.deleteMany({ email, purpose: 'registration' });

    const token = jwt.sign({ userId: user._id, email: user.email, name: user.name, role: 'student' }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.status(201).json({ token, user: { id: user._id, name: user.name, email: user.email, phone: user.phone } });
  } catch (err) { res.status(500).json({ message: 'Server error.' }); }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ message: 'Email and password required.' });
    const user = await User.findOne({ email, isVerified: true });
    if (!user) return res.status(400).json({ message: 'Invalid credentials.' });
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ message: 'Invalid credentials.' });

    // send login notification email (non-blocking)
    transporter.sendMail({
      from: `"Sankalp Digital Pathshala" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: 'New Login Alert',
      html: `<p>Hello ${user.name}, a new login was detected on your account at ${new Date().toLocaleString('en-IN', {timeZone:'Asia/Kolkata'})} IST.</p>`
    }).catch(() => {});

    const token = jwt.sign({ userId: user._id, email: user.email, name: user.name, role: user.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: { id: user._id, name: user.name, email: user.email, phone: user.phone } });
  } catch (err) { res.status(500).json({ message: 'Server error.' }); }
});

app.post('/api/auth/admin-login', async (req, res) => {
  const { email, password } = req.body;
  if (email === process.env.ADMIN_EMAIL && password === process.env.ADMIN_PASSWORD) {
    const token = jwt.sign({ email, role: 'admin' }, process.env.JWT_SECRET, { expiresIn: '1d' });
    return res.json({ token });
  }
  res.status(401).json({ message: 'Invalid admin credentials.' });
});

app.post('/api/auth/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ message: 'Email required.' });
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: 'No account found.' });
    await OTP.deleteMany({ email, purpose: 'reset' });
    const otp = generateOTP();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000);
    await new OTP({ email, otp, expiresAt, purpose: 'reset' }).save();
    await transporter.sendMail({
      from: `"Sankalp Digital Pathshala" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: 'Password Reset OTP',
      html: `<h2>Reset Your Password</h2><p>Your OTP is: <strong>${otp}</strong></p><p>Expires in 10 minutes.</p>`
    });
    res.json({ message: 'OTP sent to your email.' });
  } catch (err) { res.status(500).json({ message: 'Server error.' }); }
});

app.post('/api/auth/verify-reset-otp', async (req, res) => {
  try {
    const { email, otp } = req.body;
    const record = await OTP.findOne({ email, otp, purpose: 'reset' });
    if (!record) return res.status(400).json({ message: 'Invalid OTP.' });
    if (record.verified) return res.status(400).json({ message: 'OTP already used.' });
    if (new Date() > record.expiresAt) return res.status(400).json({ message: 'OTP expired.' });
    record.verified = true; await record.save();
    res.json({ message: 'OTP verified.' });
  } catch (err) { res.status(500).json({ message: 'Server error.' }); }
});

app.post('/api/auth/reset-password', async (req, res) => {
  try {
    const { email, otp, newPassword } = req.body;
    if (!email || !otp || !newPassword) return res.status(400).json({ message: 'All fields required.' });
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ message: 'User not found.' });
    const otpRecord = await OTP.findOne({ email, otp, verified: true, purpose: 'reset' });
    if (!otpRecord) return res.status(400).json({ message: 'OTP not verified.' });
    user.password = await bcrypt.hash(newPassword, 10);
    await user.save();
    await OTP.deleteMany({ email, purpose: 'reset' });
    res.json({ message: 'Password updated. You can now login.' });
  } catch (err) { res.status(500).json({ message: 'Server error.' }); }
});

// ========== COURSE ROUTES (order matters) ==========
app.get('/api/courses', async (req, res) => {
  const courses = await Course.find().sort({ createdAt: -1 }).lean();
  res.json(courses);
});

app.post('/api/courses/enroll', authMiddleware, async (req, res) => {
  const { courseId } = req.body;
  const userEmail = req.user.email;
  if (await Enrollment.findOne({ userEmail, courseId })) return res.status(400).json({ message: 'Already enrolled.' });
  await new Enrollment({ userEmail, courseId }).save();
  res.status(201).json({ message: 'Enrolled.' });
});

app.get('/api/courses/my-enrollments', authMiddleware, async (req, res) => {
  const enrollments = await Enrollment.find({ userEmail: req.user.email }).populate('courseId').lean();
  const courses = enrollments.map(e => e.courseId).filter(Boolean);
  res.json(courses);
});

app.get('/api/courses/:id', async (req, res) => {
  const course = await Course.findById(req.params.id).lean();
  if (!course) return res.status(404).json({ message: 'Not found.' });
  res.json(course);
});

// ========== PROGRESS ROUTES ==========
app.get('/api/progress/my-report', authMiddleware, async (req, res) => {
  try {
    const completions = await LectureProgress.find({ userEmail: req.user.email })
      .populate({ path: 'courseId', select: 'title chapters' })
      .sort({ completedAt: -1 })
      .lean();
    const enriched = await Promise.all(completions.map(async (c) => {
      const course = c.courseId;
      let lecture = null;
      if (course?.chapters) {
        for (let ch of course.chapters) {
          lecture = ch.lectures.find(l => l._id.toString() === c.lectureId);
          if (lecture) break;
        }
      }
      return { courseTitle: course?.title || 'Deleted Course', lectureTitle: lecture?.title || 'Unknown Lecture', completedAt: c.completedAt };
    }));
    res.json(enriched);
  } catch (err) { res.status(500).json({ message: 'Server error.' }); }
});

app.get('/api/progress/:courseId', authMiddleware, async (req, res) => {
  const progress = await LectureProgress.find({ userEmail: req.user.email, courseId: req.params.courseId });
  res.json(progress.map(p => p.lectureId));
});

app.post('/api/progress/mark-complete/:courseId/:lectureId', authMiddleware, async (req, res) => {
  try {
    const { courseId, lectureId } = req.params;
    if (await LectureProgress.findOne({ userEmail: req.user.email, courseId, lectureId })) return res.status(400).json({ message: 'Already completed.' });
    await new LectureProgress({ userEmail: req.user.email, courseId, lectureId }).save();
    res.json({ message: 'Lecture marked as complete.' });
  } catch (err) { res.status(500).json({ message: 'Server error.' }); }
});

// ========== DOUBTS ROUTES ==========
app.post('/api/doubts', authMiddleware, async (req, res) => {
  try {
    const { courseId, chapterId, lectureId, message, parentId } = req.body;
    const user = await User.findOne({ email: req.user.email });
    await new Doubt({ userEmail: req.user.email, userName: user?.name || req.user.email, courseId, chapterId: chapterId || null, lectureId, message, parentId: parentId || null }).save();
    res.status(201).json({ message: 'Doubt submitted.' });
  } catch (err) { res.status(500).json({ message: 'Server error.' }); }
});

app.get('/api/doubts/:courseId/:lectureId', async (req, res) => {
  const { courseId, lectureId } = req.params;
  const topLevel = await Doubt.find({ courseId, lectureId, parentId: null }).sort({ createdAt: -1 }).lean();
  for (let d of topLevel) {
    d.replies = await Doubt.find({ parentId: d._id }).sort({ createdAt: 1 }).lean();
    if (d.adminReply?.trim()) {
      d.replies.push({ _id: 'admin-' + d._id, userEmail: 'admin', userName: 'Admin', message: d.adminReply, createdAt: d.updatedAt || d.createdAt, isAdminReply: true });
    }
  }
  res.json(topLevel);
});

app.get('/api/doubts/my', authMiddleware, async (req, res) => {
  const doubts = await Doubt.find({ userEmail: req.user.email }).sort({ createdAt: -1 }).lean();
  res.json(doubts);
});

// ========== ADMIN ROUTES ==========
app.get('/api/admin/stats', adminMiddleware, async (req, res) => {
  const totalCourses = await Course.countDocuments();
  const totalStudents = await User.countDocuments({ isVerified: true });
  const totalEnrollments = await Enrollment.countDocuments();
  res.json({ totalCourses, totalStudents, totalEnrollments });
});

app.post('/api/admin/courses', adminMiddleware, async (req, res) => {
  try {
    const { title, description, price, originalPrice, imageUrl, chapters } = req.body;
    const course = new Course({ title, description, price, originalPrice: originalPrice || null, imageUrl: imageUrl || 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=600', chapters: chapters || [] });
    await course.save();
    res.status(201).json(course);
  } catch (err) { res.status(500).json({ message: 'Server error.' }); }
});

app.put('/api/admin/courses/:id', adminMiddleware, async (req, res) => {
  try {
    const { title, description, price, originalPrice, imageUrl, chapters } = req.body;
    const updated = await Course.findByIdAndUpdate(req.params.id, { title, description, price, originalPrice, imageUrl, chapters }, { new: true, runValidators: true });
    if (!updated) return res.status(404).json({ message: 'Course not found.' });
    res.json(updated);
  } catch (err) { res.status(500).json({ message: 'Update failed.' }); }
});

app.delete('/api/admin/courses/:id', adminMiddleware, async (req, res) => {
  await Course.findByIdAndDelete(req.params.id);
  await Enrollment.deleteMany({ courseId: req.params.id });
  res.json({ message: 'Course deleted.' });
});

app.post('/api/admin/courses/:id/chapters', adminMiddleware, async (req, res) => { /* unchanged */ });
app.put('/api/admin/courses/:id/chapters/:chapterId', adminMiddleware, async (req, res) => { /* unchanged */ });
app.delete('/api/admin/courses/:id/chapters/:chapterId', adminMiddleware, async (req, res) => { /* unchanged */ });
app.post('/api/admin/courses/:id/chapters/:chapterId/lectures', adminMiddleware, async (req, res) => { /* unchanged */ });
app.put('/api/admin/courses/:id/chapters/:chapterId/lectures/:lectureId', adminMiddleware, async (req, res) => { /* unchanged */ });
app.delete('/api/admin/courses/:id/chapters/:chapterId/lectures/:lectureId', adminMiddleware, async (req, res) => { /* unchanged */ });

app.get('/api/admin/students', adminMiddleware, async (req, res) => {
  const students = await User.find({ isVerified: true }).lean();
  for (let s of students) s.completedLectures = await LectureProgress.countDocuments({ userEmail: s.email });
  res.json(students);
});

app.post('/api/admin/assign', adminMiddleware, async (req, res) => {
  try {
    const { userEmail, courseId } = req.body;
    if (await Enrollment.findOne({ userEmail, courseId })) return res.status(400).json({ message: 'Already enrolled.' });
    await new Enrollment({ userEmail, courseId }).save();
    res.status(201).json({ message: 'Assigned.' });
  } catch (err) { res.status(500).json({ message: 'Server error.' }); }
});

app.get('/api/admin/doubts', adminMiddleware, async (req, res) => {
  try {
    const topDoubts = await Doubt.find({ parentId: null }).sort({ createdAt: -1 }).lean();
    const enriched = await Promise.all(topDoubts.map(async (d) => {
      const course = await Course.findById(d.courseId).lean();
      let chapterTitle = 'Deleted Chapter', lectureTitle = 'Deleted Lecture';
      if (course?.chapters) {
        for (let ch of course.chapters) {
          if (ch._id.toString() === d.chapterId) {
            chapterTitle = ch.title;
            const lec = ch.lectures.find(l => l._id.toString() === d.lectureId);
            if (lec) lectureTitle = lec.title;
            break;
          }
        }
      }
      return { ...d, courseTitle: course?.title || 'Deleted Course', chapterTitle, lectureTitle };
    }));
    res.json(enriched);
  } catch (err) { res.status(500).json({ message: 'Server error.' }); }
});

app.put('/api/admin/doubts/:id', adminMiddleware, async (req, res) => {
  const { adminReply } = req.body;
  const doubt = await Doubt.findByIdAndUpdate(req.params.id, { adminReply }, { new: true });
  if (!doubt) return res.status(404).json({ message: 'Doubt not found.' });
  res.json(doubt);
});

// ========== TEST ADMIN ROUTES ==========
app.post('/api/admin/tests', adminMiddleware, async (req, res) => {
  try {
    const { courseId, title, description, duration, language, startTime, endTime, isLive, negativeMarking, questions } = req.body;
    const test = new Test({ courseId, title, description, duration, language, startTime, endTime, isLive: isLive || false, negativeMarking: negativeMarking || 0, questions: questions || [] });
    await test.save();
    res.status(201).json(test);
  } catch (err) { res.status(500).json({ message: 'Server error.' }); }
});

app.get('/api/admin/tests/:courseId', adminMiddleware, async (req, res) => {
  const tests = await Test.find({ courseId: req.params.courseId }).sort({ createdAt: -1 }).lean();
  res.json(tests);
});

app.put('/api/admin/tests/:id', adminMiddleware, async (req, res) => {
  try {
    const { title, description, duration, language, startTime, endTime, isLive, negativeMarking, questions } = req.body;
    const test = await Test.findByIdAndUpdate(req.params.id, { title, description, duration, language, startTime, endTime, isLive, negativeMarking, questions }, { new: true, runValidators: true });
    if (!test) return res.status(404).json({ message: 'Test not found.' });
    res.json(test);
  } catch (err) { res.status(500).json({ message: 'Update failed.' }); }
});

app.delete('/api/admin/tests/:id', adminMiddleware, async (req, res) => {
  await Test.findByIdAndDelete(req.params.id);
  await TestAttempt.deleteMany({ testId: req.params.id });
  res.json({ message: 'Test deleted.' });
});

app.get('/api/admin/tests/:id/attempts', adminMiddleware, async (req, res) => {
  const attempts = await TestAttempt.find({ testId: req.params.id, completed: true }).sort({ score: -1 }).lean();
  const enriched = await Promise.all(attempts.map(async (a) => {
    const user = await User.findOne({ email: a.userEmail }).select('name email').lean();
    return { ...a, userName: user?.name, userEmail: a.userEmail };
  }));
  res.json(enriched);
});

app.get('/api/admin/attempts/:attemptId', adminMiddleware, async (req, res) => {
  const attempt = await TestAttempt.findById(req.params.attemptId).populate('testId', 'title duration').lean();
  if (!attempt) return res.status(404).json({ message: 'Not found.' });
  const test = await Test.findById(attempt.testId._id || attempt.testId).lean();
  res.json({ attempt, test });
});

// ========== STUDENT TEST ROUTES ==========
app.get('/api/tests/course/:courseId', authMiddleware, async (req, res) => {
  const now = new Date();
  const tests = await Test.find({
    courseId: req.params.courseId,
    isLive: true,
    $or: [
      { startTime: null, endTime: null },
      { startTime: { $lte: now }, endTime: { $gte: now } }
    ]
  }).select('-questions.correctAnswer').sort({ createdAt: -1 }).lean();
  res.json(tests);
});

app.get('/api/tests/:id', authMiddleware, async (req, res) => {
  const test = await Test.findById(req.params.id).select('-questions.correctAnswer').lean();
  if (!test) return res.status(404).json({ message: 'Test not found.' });
  res.json(test);
});

app.post('/api/tests/:id/start', authMiddleware, async (req, res) => {
  try {
    const test = await Test.findById(req.params.id);
    if (!test) return res.status(404).json({ message: 'Test not found.' });
    const existing = await TestAttempt.findOne({ testId: req.params.id, userEmail: req.user.email, completed: true });
    if (existing) return res.status(400).json({ message: 'You have already taken this test.' });
    const attempt = new TestAttempt({ testId: req.params.id, userEmail: req.user.email, startTime: new Date(), totalMarks: test.questions.reduce((s, q) => s + q.marks, 0) });
    await attempt.save();
    res.status(201).json({ attemptId: attempt._id, startTime: attempt.startTime });
  } catch (err) { res.status(500).json({ message: 'Server error.' }); }
});

app.post('/api/tests/:id/submit', authMiddleware, async (req, res) => {
  try {
    const { attemptId, answers, tabSwitchCount } = req.body;
    const attempt = await TestAttempt.findById(attemptId);
    if (!attempt) return res.status(404).json({ message: 'Attempt not found.' });
    if (attempt.completed) return res.status(400).json({ message: 'Already submitted.' });
    const test = await Test.findById(req.params.id);
    let score = 0;
    const gradedAnswers = answers.map(ans => {
      const question = test.questions.id(ans.questionId);
      const isCorrect = question && question.correctAnswer.trim().toLowerCase() === ans.selectedAnswer.trim().toLowerCase();
      let marksObtained = 0;
      if (isCorrect) marksObtained = question.marks;
      else if (ans.selectedAnswer.trim() !== '') marksObtained = -test.negativeMarking;
      score += marksObtained;
      return { questionId: ans.questionId, selectedAnswer: ans.selectedAnswer, isCorrect, marksObtained };
    });
    attempt.endTime = new Date();
    attempt.score = score;
    attempt.answers = gradedAnswers;
    attempt.completed = true;
    attempt.tabSwitchCount = tabSwitchCount || 0;
    await attempt.save();
    res.json({ score, totalMarks: attempt.totalMarks, attemptId: attempt._id });
  } catch (err) { res.status(500).json({ message: 'Server error.' }); }
});

app.get('/api/tests/result/:attemptId', authMiddleware, async (req, res) => {
  const attempt = await TestAttempt.findById(req.params.attemptId).populate('testId', 'title duration').lean();
  if (!attempt) return res.status(404).json({ message: 'Attempt not found.' });
  const test = await Test.findById(attempt.testId._id || attempt.testId).lean();
  res.json({ attempt, test });
});

app.get('/api/tests/:id/my-attempts', authMiddleware, async (req, res) => {
  const attempts = await TestAttempt.find({ testId: req.params.id, userEmail: req.user.email }).sort({ createdAt: -1 }).lean();
  res.json(attempts);
});

app.get('/api/tests/:id/leaderboard', async (req, res) => {
  const attempts = await TestAttempt.find({ testId: req.params.id, completed: true }).sort({ score: -1, endTime: 1 }).limit(50).lean();
  const enriched = await Promise.all(attempts.map(async (a) => {
    const user = await User.findOne({ email: a.userEmail }).select('name').lean();
    return { ...a, userName: user?.name || 'Unknown' };
  }));
  res.json(enriched);
});

// AI Explanation per question
app.post('/api/tests/:testId/question/:questionId/explain', authMiddleware, async (req, res) => {
  const test = await Test.findById(req.params.testId);
  const question = test?.questions.id(req.params.questionId);
  if (!question) return res.status(404).json({ message: 'Question not found.' });
  try {
    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: "meta-llama/llama-3.3-70b-instruct:free",
        messages: [
          { role: "system", content: "You are a helpful teacher. Explain the following question clearly, state the correct answer, and give reasoning." },
          { role: "user", content: `Question: ${question.questionText}\nOptions: ${question.options?.join(', ')}\nCorrect Answer: ${question.correctAnswer}` }
        ],
        stream: false
      })
    });
    const data = await response.json();
    res.json({ explanation: data.choices?.[0]?.message?.content || 'No explanation available.' });
  } catch (err) { res.status(500).json({ message: 'AI error' }); }
});

// ========== PRACTICE TEST GENERATION (AI) ==========
app.post('/api/practice/generate', authMiddleware, async (req, res) => {
  const { topic, difficulty } = req.body;
  try {
    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: "meta-llama/llama-3.3-70b-instruct:free",
        messages: [
          { role: "system", content: `Generate exactly 10 MCQ questions on "${topic}" at ${difficulty} difficulty. Return ONLY a JSON array (no other text) with fields: type ("mcq"), questionText, options (array of 4 strings), correctAnswer (string), marks (1), explanation (string).` }
        ],
        temperature: 0.7
      })
    });
    const data = await response.json();
    let questions = [];
    try {
      const raw = data.choices?.[0]?.message?.content;
      const jsonStr = raw.replace(/```json|```/g, '').trim();
      questions = JSON.parse(jsonStr);
    } catch (e) { return res.status(500).json({ message: 'Failed to parse AI response.' }); }
    if (!Array.isArray(questions) || questions.length === 0) return res.status(500).json({ message: 'No questions generated.' });
    const practice = new PracticeTest({
      userEmail: req.user.email,
      topic,
      difficulty,
      questions,
      startedAt: new Date(),
      totalMarks: questions.reduce((s, q) => s + (q.marks || 1), 0)
    });
    await practice.save();
    res.json({ practiceId: practice._id, questions });
  } catch (err) { res.status(500).json({ message: 'Server error.' }); }
});

app.post('/api/practice/:id/submit', authMiddleware, async (req, res) => {
  try {
    const { answers } = req.body;
    const practice = await PracticeTest.findById(req.params.id);
    if (!practice || practice.completed) return res.status(400).json({ message: 'Already submitted or not found.' });
    let score = 0;
    const graded = answers.map(ans => {
      const question = practice.questions.id(ans.questionId);
      const isCorrect = question && question.correctAnswer.trim().toLowerCase() === ans.selectedAnswer.trim().toLowerCase();
      const marks = isCorrect ? (question.marks || 1) : 0;
      score += marks;
      return { questionId: ans.questionId, selectedAnswer: ans.selectedAnswer, isCorrect, marksObtained: marks };
    });
    practice.completed = true;
    practice.completedAt = new Date();
    practice.score = score;
    practice.answers = graded;
    await practice.save();
    res.json({ score, totalMarks: practice.totalMarks });
  } catch (err) { res.status(500).json({ message: 'Server error.' }); }
});

// ========== AI CONVERSATION HISTORY ==========
app.post('/api/conversations', authMiddleware, async (req, res) => {
  const { messages } = req.body;
  await Conversation.findOneAndUpdate(
    { userEmail: req.user.email },
    { messages, updatedAt: new Date() },
    { upsert: true }
  );
  res.json({ message: 'Saved.' });
});

app.get('/api/conversations/my', authMiddleware, async (req, res) => {
  const conv = await Conversation.findOne({ userEmail: req.user.email }).lean();
  res.json(conv || { messages: [] });
});

// ========== NOTIFICATIONS ==========
app.post('/api/notifications', adminMiddleware, async (req, res) => {
  const { recipient, courseId, message } = req.body;
  await new Notification({ sender: 'admin', recipient: recipient || null, courseId: courseId || null, message }).save();
  res.status(201).json({ message: 'Notification sent.' });
});

app.get('/api/notifications/my', authMiddleware, async (req, res) => {
  const notifs = await Notification.find({
    $or: [{ recipient: req.user.email }, { recipient: null }]
  }).sort({ createdAt: -1 }).lean();
  res.json(notifs);
});

// ========== DIRECT MESSAGES ==========
app.post('/api/messages', authMiddleware, async (req, res) => {
  const { to, message } = req.body;
  await new Message({ from: req.user.email, to, message }).save();
  res.status(201).json({ message: 'Sent.' });
});

app.get('/api/messages/:with', authMiddleware, async (req, res) => {
  const msgs = await Message.find({
    $or: [
      { from: req.user.email, to: req.params.with },
      { from: req.params.with, to: req.user.email }
    ]
  }).sort({ createdAt: 1 }).lean();
  res.json(msgs);
});

// ========== COMMUNITY CHAT ==========
app.post('/api/community', authMiddleware, async (req, res) => {
  const user = await User.findOne({ email: req.user.email });
  await new CommunityMessage({ userEmail: req.user.email, userName: user.name, message: req.body.message }).save();
  res.status(201).json({});
});

app.get('/api/community', authMiddleware, async (req, res) => {
  const msgs = await CommunityMessage.find().sort({ createdAt: -1 }).limit(100).lean();
  res.json(msgs.reverse());
});

// ========== ADMIN DETAILED REPORTS ==========
app.get('/api/admin/reports/student/:email', adminMiddleware, async (req, res) => {
  const email = req.params.email;
  const user = await User.findOne({ email });
  const progress = await LectureProgress.find({ userEmail: email }).populate('courseId').lean();
  const tests = await TestAttempt.find({ userEmail: email }).populate('testId').lean();
  const practiceTests = await PracticeTest.find({ userEmail: email }).lean();
  const doubts = await Doubt.find({ userEmail: email }).lean();
  const conversations = await Conversation.findOne({ userEmail: email }).lean();
  res.json({ user, progress, tests, practiceTests, doubts, conversations });
});

// ========== AI CHATBOT (Sankalp Sathi) – FULLY TRAINED ==========
app.post('/api/chat', async (req, res) => {
  const { messages } = req.body;
  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ message: 'Messages array required.' });
  }

  // UPDATED system prompt with all the details provided
  const systemMsg = {
    role: "system",
    content: `You are "Sankalp Sathi", the official AI assistant of Sankalp Digital Pathshala, a platform under the Sankalp Shiksha Foundation.

Your answers must follow these rules strictly:
- Use plain paragraphs only. Never use markdown formatting like bold (**), italic (*), headings (#), tables (|), lists (- or *), or code blocks.
- Write naturally as if you are talking to a friend. Use simple, clear sentences.
- Break information into short paragraphs (2-4 sentences each). Use a blank line between paragraphs.

About the organization – Sankalp Shiksha Foundation:

The foundation's mission is "हमारा संकल्प, सामाजिक उत्थान व कायाकल्प" (Our Pledge: Social Upliftment and Transformation). It works to close the digital divide between villages and cities.

It was founded on November 18, 2020, and is headquartered in Gorakhpur, Uttar Pradesh. The learning center called Sankalp Digital Pathshala is in Salemgarh, Tamkuhi, Kushinagar.

The founders are Abhishek Kumar and Vikas Kumar, both serving as Co-Founder and Director.

Abhishek Kumar holds a B.Tech from IIT. He is an engineer and tech entrepreneur who earlier worked in product development for a startup in Delhi. During college, he volunteered with NGOs. He was driven to start the Pathshala after seeing the growing digital divide between urban and rural India while visiting his native village in Uttar Pradesh. He wanted to bring the same quality of digital education that city kids enjoy to his own community.

Vikas Kumar holds a B.Tech in Computer Science from NIT Hamirpur. He is an engineer who later became a technical lead in a multinational IT services firm. He has experience building AI-driven platforms and robotics labs. During college, he actively participated in community-service clubs. During the COVID-19 lockdown in 2020, he and his friends were distributing food, masks, and sanitizers to stranded workers. The crisis showed him how lack of digital access made rural families even more vulnerable. This inspired him to set up a digital learning hub that could continue even during emergencies.

Why they started Sankalp Digital Pathshala: First, to bridge the digital divide by providing modern learning resources like computers, internet, and AI/Robotics labs to underprivileged children in villages of Kushinagar and surrounding districts. Second, to enable rural youth to acquire job-ready skills like web development, digital marketing, and AI basics without having to leave their hometowns. Third, to drive holistic community upliftment by combining education with health, sanitation, environmental, and livelihood initiatives.

Their journey milestones: In 2020, it started as a COVID-19 relief effort with food, masks, and sanitizers. In 2021, they launched the first digital classroom in Salemgarh, Tamkuhi. In 2022, they introduced AI and Robotics Labs with drones and automation kits. In 2023, they rolled out Rojgaar Buddy, a skilling program for youth aged 18 to 25. In 2024, they were recognized by Doordarshan for their impact on rural digital literacy. In 2025, Rojgaar Buddy had 312 plus trainees and 40 plus placements, with 73 percent from BPL families. In 2026, they are expanding to neighboring districts and discussing partnerships with the state IT ministry for scaling labs.

The Rojgaar Buddy program trains rural youth in Web Development, Graphic Design, Excel, Digital Marketing, Communication and Personality Development. Success stories include Vishal, a 22-year-old who now earns through freelance web design; Priya, who runs a small online business; and Imran, who manages a part-time digital marketing project for a local startup.

The foundation also runs community programs like cleanliness campaigns at Gomti river front, road safety awareness rallies, flood relief in UP and Bihar, COVID-19 ration distribution to over 400 families, festival celebrations with underprivileged children, and cricket competitions for talent identification.

Their vision: "Digital education is not a luxury; it is a right. By placing future-tech labs and skilled mentors in villages, we aim to create a generation that can innovate from the heart of rural India, turning local challenges into opportunities."

If a user asks who developed, created, trained, or built this AI assistant, respond that it was developed by NexGenAiTech, a modern AI and Full-Stack Development company that builds intelligent digital solutions for businesses, startups, educational organizations, and enterprises globally. Mention that NexGenAiTech was founded by Jahid, who specializes in Artificial Intelligence, automation systems, scalable web technologies, and advanced software development.

Explain that NexGenAiTech works across multiple industries including Education, Healthcare, E-Commerce, Real Estate, Finance, Retail, Startups, IT Services, Coaching Institutes, Local Businesses, and Enterprise Automation. The company helps organizations transform their operations using Artificial Intelligence, automation, cloud technologies, and smart digital platforms.

NexGenAiTech provides services such as:
• AI Chatbot Development
• Custom AI Solutions & Machine Learning Systems
• Website Design & Full-Stack Web Development
• Android & iOS Mobile App Development
• Business Automation Systems
• CRM, ERP & Admin Dashboard Development
• API Integration & Cloud Solutions
• UI/UX Design & Branding
• SEO & Digital Marketing
• Hosting, Maintenance & Technical Support
• Automation Tools & Workflow Optimization
• Educational & Training Platforms
• E-Commerce Solutions
• WhatsApp & Telegram Bot Development

Official Website: https://nexgenaitech.online

For business inquiries and project discussions:
Founder: Jahid
Phone: +91 8055698328

Keep the tone professional, intelligent, modern, and trustworthy while presenting NexGenAiTech as an innovative technology company focused on AI-powered digital transformation and scalable software solutions.

Contact: info@sankalppathshala.com, phone/WhatsApp: +91 8055698328. To donate or support, visit sankalpshiksha.com/donate.

Always answer in a friendly, warm tone. If you don't know something, say so honestly and suggest contacting the support team.`
  };

  const fullMessages = [systemMsg, ...messages];

  const models = [
    "openai/gpt-oss-120b:free",
    "meta-llama/llama-3.3-70b-instruct:free",
    "google/gemini-flash-1.5-8b:free"
  ];

  for (const model of models) {
    try {
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${process.env.OPENROUTER_API_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model,
          messages: fullMessages,
          stream: true
        })
      });

      if (response.ok) {
        res.writeHead(200, {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive'
        });

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        while (true) {
          const { done, value } = await reader.read();
          if (done) { res.end(); return; }
          res.write(decoder.decode(value));
        }
      } else if (response.status === 429) {
        console.warn(`Model ${model} rate limited.`);
        continue;
      } else {
        console.error(`Model ${model} returned ${response.status}`);
        continue;
      }
    } catch (err) {
      console.error(`Error with model ${model}:`, err.message);
      continue;
    }
  }

  // Graceful fallback
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive'
  });

  const fallback = "I'm sorry, I'm currently experiencing high demand. Please try again in a moment, or contact our support team at info@sankalppathshala.com or +91 8055698328.";
  const chunk = JSON.stringify({ choices: [{ delta: { content: fallback } }] });
  res.write(`data: ${chunk}\n\n`);
  res.write('data: [DONE]\n\n');
  res.end();
});

// ========== FRONTEND FALLBACK ==========
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
